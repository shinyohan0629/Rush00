/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush00.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dd <dd@student.42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/03/26 21:21:06 by bson              #+#    #+#             */
/*   Updated: 2021/03/26 22:12:14 by dd               ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_putchar.c"

void	ft_putchar(char c);

void	rush (int x, int y) 
{
	int		u;
	int		v;
	char	a;

	v = 1;
	while (v <= y) 
	{
		u = 1;
		while (u <= x) 
		{
			a = ' ';
			//row
			if (v == 1 || v == y) 
			{
				a = '-';
			}
			//column
			if (u == 1 || u == x) 
			{
				a = '|';
			}
			//vertex
			if (u == 1) 
			{
				if (v == 1 || v == y) 
				{
					a = 'o';
				}
			}
			if (u == x) 
			{
				if (v == 1 || v == y) 
				{
					a = 'o';
				}
			}
			ft_putchar (a);
			u++;
		}
		ft_putchar ('\n');
		v++;
	}
}
